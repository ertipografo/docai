export const features = {
	riassunto: "Riassunto",
	mappa: "Mappa Concettuale",
	quiz: "Quiz",
};
